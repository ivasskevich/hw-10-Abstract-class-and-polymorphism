﻿abstract class Shape
{
    public abstract void Show();
    public abstract double Area();
    public abstract void Save(StreamWriter writer);
    public abstract void Load(StreamReader reader);

    public static Shape CreateShape(string shapeType)
    {
        Type type = Type.GetType(shapeType);
        if (type == null || !typeof(Shape).IsAssignableFrom(type))
        {
            throw new ArgumentException("Unknown shape type");
        }
        return (Shape)Activator.CreateInstance(type);
    }
}

class Triangle : Shape
{
    private double a, b;

    public Triangle() { }

    public Triangle(double a, double b)
    {
        this.a = a;
        this.b = b;
    }

    public override void Show()
    {
        Console.WriteLine($"Triangle with sides a = {a}, b = {b}");
    }

    public override double Area()
    {
        return 0.5 * a * b;
    }

    public override void Save(StreamWriter writer)
    {
        writer.WriteLine(GetType().FullName);
        writer.WriteLine(a);
        writer.WriteLine(b);
    }

    public override void Load(StreamReader reader)
    {
        a = double.Parse(reader.ReadLine());
        b = double.Parse(reader.ReadLine());
    }
}

class Rectangle : Shape
{
    private double x1, y1, x2, y2;

    public Rectangle() { }

    public Rectangle(double x1, double y1, double x2, double y2)
    {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
    }

    public override void Show()
    {
        Console.WriteLine($"Rectangle from ({x1}, {y1}) to ({x2}, {y2})");
    }

    public override double Area()
    {
        return Math.Abs(x2 - x1) * Math.Abs(y2 - y1);
    }

    public override void Save(StreamWriter writer)
    {
        writer.WriteLine(GetType().FullName);
        writer.WriteLine(x1);
        writer.WriteLine(y1);
        writer.WriteLine(x2);
        writer.WriteLine(y2);
    }

    public override void Load(StreamReader reader)
    {
        x1 = double.Parse(reader.ReadLine());
        y1 = double.Parse(reader.ReadLine());
        x2 = double.Parse(reader.ReadLine());
        y2 = double.Parse(reader.ReadLine());
    }
}

class Circle : Shape
{
    private double x, y, radius;

    public Circle() { }

    public Circle(double x, double y, double radius)
    {
        this.x = x;
        this.y = y;
        this.radius = radius;
    }

    public override void Show()
    {
        Console.WriteLine($"Circle with center ({x}, {y}) and radius {radius}");
    }

    public override double Area()
    {
        return Math.PI * radius * radius;
    }

    public override void Save(StreamWriter writer)
    {
        writer.WriteLine(GetType().FullName);
        writer.WriteLine(x);
        writer.WriteLine(y);
        writer.WriteLine(radius);
    }

    public override void Load(StreamReader reader)
    {
        x = double.Parse(reader.ReadLine());
        y = double.Parse(reader.ReadLine());
        radius = double.Parse(reader.ReadLine());
    }
}

class ShapeCollection
{
    private Shape[] shapes;
    private int count;

    public ShapeCollection(int size)
    {
        shapes = new Shape[size];
        count = 0;
    }

    public void AddShape(Shape shape)
    {
        if (count < shapes.Length)
        {
            shapes[count++] = shape;
        }
        else
        {
            Console.WriteLine("Shape array is full.");
        }
    }

    public void RemoveShape(int index)
    {
        if (index >= 0 && index < count)
        {
            for (int i = index; i < count - 1; i++)
            {
                shapes[i] = shapes[i + 1];
            }
            shapes[--count] = null;
        }
        else
        {
            Console.WriteLine("Invalid index.");
        }
    }

    public void PrintAllShapes()
    {
        for (int i = 0; i < count; i++)
        {
            shapes[i].Show();
        }
    }

    public void PrintShapesByType(string shapeType)
    {
        foreach (var shape in shapes.Take(count))
        {
            if (shape is Triangle && shapeType == "Triangle")
            {
                shape.Show();
            }
            else if (shape is Rectangle && shapeType == "Rectangle")
            {
                shape.Show();
            }
            else if (shape is Circle && shapeType == "Circle")
            {
                shape.Show();
            }
        }
    }

    public double CalculateTotalArea()
    {
        double totalArea = 0;
        for (int i = 0; i < count; i++)
        {
            totalArea += shapes[i].Area();
        }
        return totalArea;
    }

    public double CalculateAreaByType(string shapeType)
    {
        double totalArea = 0;

        foreach (var shape in shapes.Take(count))
        {
            if (shapeType == "Triangle")
            {
                var triangle = shape as Triangle;
                if (triangle != null)
                {
                    totalArea += triangle.Area();
                }
            }
            else if (shapeType == "Rectangle")
            {
                var rectangle = shape as Rectangle;
                if (rectangle != null)
                {
                    totalArea += rectangle.Area();
                }
            }
            else if (shapeType == "Circle")
            {
                var circle = shape as Circle;
                if (circle != null)
                {
                    totalArea += circle.Area();
                }
            }
        }

        return totalArea;
    }


    public void SaveShapes(string filePath)
    {
        try
        {
            using StreamWriter writer = new StreamWriter(filePath);
            for (int i = 0; i < count; i++)
            {
                shapes[i].Save(writer);
            }
        }
        catch (Exception e)
        {
            Console.WriteLine("Error saving shapes: " + e.Message);
        }
    }

    public void LoadShapes(string filePath)
    {
        try
        {
            using StreamReader reader = new StreamReader(filePath);
            count = 0;
            while (!reader.EndOfStream)
            {
                string shapeType = reader.ReadLine();
                Shape shape = Shape.CreateShape(shapeType);
                shape.Load(reader);
                shapes[count++] = shape;
            }
        }
        catch (Exception e)
        {
            Console.WriteLine("Error loading shapes: " + e.Message);
        }
    }
}

class Program
{
    static void Main()
    {
        ShapeCollection collection = new ShapeCollection(10);
        bool exit = false;

        while (!exit)
        {
            try
            {
                Console.WriteLine("\nMenu:");
                Console.WriteLine("1. Add Triangle");
                Console.WriteLine("2. Add Rectangle");
                Console.WriteLine("3. Add Circle");
                Console.WriteLine("4. Print All Shapes");
                Console.WriteLine("5. Print Shapes by Type");
                Console.WriteLine("6. Calculate Total Area");
                Console.WriteLine("7. Calculate Area by Type");
                Console.WriteLine("8. Save Shapes to File");
                Console.WriteLine("9. Load Shapes from File");
                Console.WriteLine("10. Remove Shape");
                Console.WriteLine("11. Exit");
                Console.Write("Choose an option: ");
                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.Write("Enter side a: ");
                        double a = double.Parse(Console.ReadLine());
                        Console.Write("Enter side b: ");
                        double b = double.Parse(Console.ReadLine());
                        collection.AddShape(new Triangle(a, b));
                        break;

                    case 2:
                        Console.Write("Enter x1: ");
                        double x1 = double.Parse(Console.ReadLine());
                        Console.Write("Enter y1: ");
                        double y1 = double.Parse(Console.ReadLine());
                        Console.Write("Enter x2: ");
                        double x2 = double.Parse(Console.ReadLine());
                        Console.Write("Enter y2: ");
                        double y2 = double.Parse(Console.ReadLine());
                        collection.AddShape(new Rectangle(x1, y1, x2, y2));
                        break;

                    case 3:
                        Console.Write("Enter center x: ");
                        double cx = double.Parse(Console.ReadLine());
                        Console.Write("Enter center y: ");
                        double cy = double.Parse(Console.ReadLine());
                        Console.Write("Enter radius: ");
                        double radius = double.Parse(Console.ReadLine());
                        collection.AddShape(new Circle(cx, cy, radius));
                        break;

                    case 4:
                        collection.PrintAllShapes();
                        break;

                    case 5:
                        Console.Write("Enter shape type to print (e.g., 'Triangle', 'Rectangle', 'Circle'): ");
                        string shapeTypeToPrint = Console.ReadLine();
                        collection.PrintShapesByType(shapeTypeToPrint);
                        break;

                    case 6:
                        Console.WriteLine("Total Area: " + collection.CalculateTotalArea());
                        break;

                    case 7:
                        Console.Write("Enter shape type to calculate area (e.g., 'Triangle', 'Rectangle', 'Circle'): ");
                        string shapeTypeToCalculate = Console.ReadLine();
                        Console.WriteLine("Total Area for " + shapeTypeToCalculate + ": " + collection.CalculateAreaByType(shapeTypeToCalculate));
                        break;

                    case 8:
                        Console.Write("Enter file path to save: ");
                        string savePath = Console.ReadLine();
                        collection.SaveShapes(savePath);
                        break;

                    case 9:
                        Console.Write("Enter file path to load: ");
                        string loadPath = Console.ReadLine();
                        collection.LoadShapes(loadPath);
                        break;

                    case 10:
                        Console.Write("Enter index of shape to remove: ");
                        int indexToRemove = int.Parse(Console.ReadLine());
                        collection.RemoveShape(indexToRemove);
                        break;

                    case 11:
                        exit = true;
                        break;

                    default:
                        Console.WriteLine("Invalid option.");
                        break;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: " + e.Message);
            }
        }
    }
}
